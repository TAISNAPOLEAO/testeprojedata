package func.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Date;

import conexao.Connectionconexao;
import packageprojedata.Funcionario;
import packageprojedata.Pessoa;
import packageprojedata.Principal;

public class FuncDao {
	
	//CRUD - create, read, update, delete
	
	public void save(Pessoa pessoa, Funcionario funcionario) {
		
		String sql = "INSERT INTO funcionarios(nome, dt_nasc, salario, funcao) VALUES (?, ?, ?, ?)";
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		try {
			conn = Connectionconexao.createConnectionToMySQL();
			
			pstm = conn.prepareStatement(sql);
			pstm.setString(1, pessoa.getNome());
			pstm.setDate(2, pessoa.getDatanasc());
			pstm.setBigDecimal(3, funcionario.getSalario());
			pstm.setString(4, funcionario.getFuncao());
			
			pstm.execute();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstm!=null) {
					pstm.close();
				}
				if(conn!=null) {
					conn.close();
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
	}
	
}
