package packageprojedata;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;


public class Pessoa {

		
		private String nome;
		private Date datanasc;
		
		
		public String getNome() {
			return nome;
		}
		public void setNome(String nome) {
			this.nome = nome;
		}
		public Date getDatanasc() {
			return datanasc;
		}
		
		public void setDatanasc(LocalDate dateTimeFormatter) {
			this.datanasc = dateTimeFormatter;
		}

	
}
