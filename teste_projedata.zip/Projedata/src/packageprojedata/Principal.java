package packageprojedata;

import java.time.format.DateTimeFormatter;
import java.util.Formatter;
import java.util.Scanner;

import func.dao.FuncDao;



public class Principal {

	public static void main(String[] args) {
		
		Pessoa pessoa = new Pessoa();
		pessoa.setNome("Maria");
		//pessoa.setDatanasc(DateTimeFormatter.ofLocalizedDateTime("01/01/2000"));
		
		Funcionario funcionario = new Funcionario();
		//funcionario.setSalario(2009.44);
		funcionario.setFuncao("Operador");
		
		FuncDao funcdao = new FuncDao();
		
		funcdao.save(pessoa, funcionario);
		
		/*
		 * Tenho muita experiencia em suporte a sistemas e negocios. No momento quero migrar para area de desenvolvimento
		 * e também estou a procura de um estágio.
		 * 
		 * O que eu fiz no java foi com conhecimento academico. Os demais exercicios eu fiz com o meu conhecimento e experiencia 
		 * em banco de dados
		 * 
		 * 3 - 
				select * from funcionarios
				
				3.1 – Inserir todos os funcionários, na mesma ordem e informações da tabela acima.
				
				insert into funcionarios (nome, dt_nasc, salario, funcao)values 
				('Joao', STR_TO_DATE( "12/05/1990", "%m/%d/%Y" ), 2000.44, 'Operador'),
				('Caio', STR_TO_DATE("02/05/1961", "%m/%d/%Y"), 9836.14, 'Coordenador'),
				('Miguel', STR_TO_DATE("14/10/1988", "%d/%m/%Y"), 19119.88, 'Diretor'),
				('Alice', STR_TO_DATE("05/01/1995", "%d/%m/%Y"), 2234.68, 'Recepcionista'),
				('Heitor', STR_TO_DATE("19/11/1999", "%d/%m/%Y"), 1582.72, 'Operador'),
				('Arthur', STR_TO_DATE("31/03/1993", "%d/%m/%Y"), 4071.84, 'Contador'),
				('Laura', STR_TO_DATE("08/07/1994", "%d/%m/%Y"), 3017.45, 'Gerente'),
				('Heloisa', STR_TO_DATE("24/05/2003", "%d/%m/%Y"), 1606.85, 'Eletricista'),
				('Helena', STR_TO_DATE("02/09/1996", "%d/%m/%Y"), 2799.93, 'Gerente');
				
				3.2 – Remover o funcionário “João” da lista.
				
				select nome, date_format(dt_nasc, "%m/%d/%Y"), salario, funcao from funcionarios where nome = 'Joao';
				SET SQL_SAFE_UPDATES = 0;
				delete from funcionarios where  nome = 'Joao';
				SET SQL_SAFE_UPDATES = 1;
				
				3.3 – Imprimir todos os funcionários com todas suas informações, sendo que:
				
				• informação de data deve ser exibido no formato dd/mm/aaaa;
				
				select nome, date_format(dt_nasc, "%m/%d/%Y"), salario, funcao from funcionarios;
				
				• informação de valor numérico deve ser exibida no formatado com separador de milhar como ponto e decimal como vírgula.
				
				select format(salario, 2, 'de_DE') from funcionarios;
				
				3.4 – Os funcionários receberam 10% de aumento de salário, atualizar a lista de funcionários com novo valor.
				
				select nome, dt_nasc, format(((salario * 10) / 100) + salario, 2, 'de_DE' ) as 'salario', funcao from funcionarios;
				
				3.5 – Agrupar os funcionários por função em um MAP, sendo a chave a “função” e o valor a “lista de funcionários”.
				Não fiz, não sei
				
				3.6 – Imprimir os funcionários, agrupados por função.
				
				select funcao, count(*) from funcionarios group by funcao;
				
				3.8 – Imprimir os funcionários que fazem aniversário no mês 10 e 12.
				
				select dt_nasc from funcionarios where dt_nasc like '%10%' or dt_nasc like '%12%';
				
				3.9 – Imprimir o funcionário com a maior idade, exibir os atributos: nome e idade.
				
				SET @@sql_mode = sys.list_drop(@@sql_mode, 'ONLY_FULL_GROUP_BY');
				select nome, max(date_format(curdate(), '%Y') - DATE_FORMAT(dt_nasc, '%Y')) as 'idade' from funcionarios where dt_nasc is not null 
				order by nome, idade;
				
				3.10 – Imprimir a lista de funcionários por ordem alfabética.
				
				select * from funcionarios order by nome asc;
				
				3.11 – Imprimir o total dos salários dos funcionários.
				
				select format(sum(salario), 2, 'de_DE') from funcionarios;
				
				3.12 – Imprimir quantos salários mínimos ganha cada funcionário, considerando que o salário mínimo é R$1212.00.
				
				select nome, dt_nasc, format(((salario / 1212.00)), 0, 'de_DE')  as 'salario', funcao from funcionarios;
				
				
				
						 * 
		 * 
		 */
		
		
	}

}
